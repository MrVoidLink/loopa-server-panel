import React from "react";
import StatsCard from "../components/StatsCard";
import { Link } from "react-router-dom";

function DashboardPage() {
  return (
    <div className="min-h-screen bg-[#0a0a14] text-white relative overflow-hidden flex flex-col items-center justify-center px-6">
      {/* پس‌زمینه متحرک */}
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 via-transparent to-cyan-400/10 blur-3xl animate-pulse"></div>

      {/* محتوای اصلی */}
      <div className="relative z-10 text-center animate-fade-in">
        <h1 className="text-4xl font-extrabold text-emerald-400 drop-shadow-[0_0_15px_rgba(52,211,153,0.4)] mb-2">
          🌀 Loopa Dashboard
        </h1>
        <p className="text-gray-400 mb-10 tracking-wide">Welcome, Mr Void 👋</p>

        {/* کارت‌های آمار */}
        <div className="flex flex-wrap justify-center gap-6 mb-10">
          <StatsCard title="Active Servers" value="3" />
          <StatsCard title="Online Users" value="127" />
          <StatsCard title="Daily Requests" value="4.5k" />
        </div>

        {/* دکمه رفتن به صفحه سرورها */}
        <Link
          to="/servers"
          className="inline-block px-6 py-2 text-lg font-medium text-black bg-emerald-500 rounded-lg shadow-md 
                     hover:bg-emerald-400 hover:shadow-emerald-400/40 transition-all duration-300"
        >
          → Go to Servers Page
        </Link>
      </div>

      {/* نور پایین صفحه */}
      <div className="absolute bottom-0 w-full h-[120px] bg-gradient-to-t from-emerald-500/10 to-transparent"></div>
    </div>
  );
}

export default DashboardPage;
