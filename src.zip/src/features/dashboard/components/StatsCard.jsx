import React from "react";

function StatsCard({ title, value }) {
  return (
    <div className="bg-white/10 backdrop-blur-md border border-white/10 text-white rounded-2xl p-5 w-48 
                    shadow-md hover:shadow-emerald-400/30 hover:scale-[1.04] transition-all duration-300">
      <h3 className="text-gray-400 mb-1 text-sm">{title}</h3>
      <h2 className="text-2xl font-bold text-emerald-400 drop-shadow-[0_0_8px_rgba(52,211,153,0.5)]">
        {value}
      </h2>
    </div>
  );
}

export default StatsCard;
