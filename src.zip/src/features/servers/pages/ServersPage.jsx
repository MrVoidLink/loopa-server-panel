import React from "react";
import { Link } from "react-router-dom";

function ServersPage() {
  return (
    <div className="min-h-screen bg-[#0f0f1a] text-white flex flex-col items-center justify-center px-4">
      <h1 className="text-3xl font-bold mb-2">🖥️ Servers Page</h1>
      <p className="text-gray-400 mb-8">
        Here will be the list of all Loopa servers.
      </p>

      <Link
        to="/"
        className="text-emerald-400 font-medium hover:text-emerald-300 transition"
      >
        ← Back to Dashboard
      </Link>
    </div>
  );
}

export default ServersPage;
