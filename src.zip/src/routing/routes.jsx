import React from "react";
import { createBrowserRouter } from "react-router-dom";
import App from "../app/App";

// صفحات
import DashboardPage from "../features/dashboard/pages/DashboardPage";
import ServersPage from "../features/servers/pages/ServersPage";
import LoginPage from "../features/login/pages/LoginPage"; // 🔹 مسیر جدید

export const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      { path: "/", element: <DashboardPage /> },
      { path: "/servers", element: <ServersPage /> },
    ],
  },

  // 🔹 مسیر جدید صفحه ورود
  {
    path: "/login",
    element: <LoginPage />,
  },
]);
